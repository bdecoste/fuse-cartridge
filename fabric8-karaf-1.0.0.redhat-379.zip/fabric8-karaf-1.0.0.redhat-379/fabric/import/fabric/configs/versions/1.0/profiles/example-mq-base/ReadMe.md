# Example ActiveMQ Base

This is the base profile for the ActiveMQ example profiles. It serves as the parent profile for the `example-mq-consumer` profile and the `example-mq-producer` profile. It is _not_ meant to be deployed directly into a container.